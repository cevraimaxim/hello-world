// Pour ouvrir le menu avec le hamburger quand il est en format petit écran
$('.header_navbar-toggle').click(function(e){
	e.preventDefault();
	$('.header_navbar').toggleClass('is-open');
})


// Pour faire défiler lentement la page avec l'acenseur 
$(function(){
    $('a[href^="#"]').click(function(){
        var the_id = $(this).attr("href");
        if (the_id == '#'){return;}

        $('html, body').animate({
            scrollTop:$(the_id).offset().top}, 'solw');
        return false;
    });
})




